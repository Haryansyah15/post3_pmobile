package com.example.post3

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ResultActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_result)

        // Ambil data dari intent
        val fullName = intent.getStringExtra("FULL_NAME")
        val username = intent.getStringExtra("USERNAME")
        val age = intent.getStringExtra("AGE")
        val email = intent.getStringExtra("EMAIL")
        val gender = intent.getStringExtra("GENDER")

        // Tampilkan di TextView
        findViewById<TextView>(R.id.tvFullName).text = fullName
        findViewById<TextView>(R.id.tvUsername).text = username
        findViewById<TextView>(R.id.tvAge).text = age
        findViewById<TextView>(R.id.tvEmail).text = email
        findViewById<TextView>(R.id.tvGender).text = gender
    }
}
